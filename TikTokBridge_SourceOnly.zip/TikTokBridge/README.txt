TikTok Bridge 0.1 - Android project with GitHub Actions APK build

Purpose:
- Pick a video with Android's system document picker.
- Share the selected content:// URI and read permission to another app.
- The bridge itself does not decode, re-encode, resize, or copy the video.

Important limitations:
- This does NOT disable TikTok's import processing or server-side transcoding.
- TikTok may not accept ACTION_SEND in every version/region. If it does not appear in the share sheet, this prototype cannot force it to.
- The app cannot make TikTok treat Android as iOS or guarantee gallery-identical playback after upload.

Build APK without Android Studio:
1. Create/sign in to a GitHub account and create a new empty repository.
2. Upload the CONTENTS of this folder (not the outer TikTokBridge folder) to the repository's main branch. Make sure .github/workflows/build-apk.yml is included. On GitHub's upload page, hidden files may need to be included; alternatively upload the ZIP using GitHub's web interface if available.
3. Open the repository's Actions tab and select "Build TikTok Bridge APK".
4. If asked, enable GitHub Actions, then press "Run workflow".
5. When the run finishes successfully, open it and download the "TikTokBridge-debug" artifact.
6. Extract the downloaded artifact ZIP on the phone and install app-debug.apk. Android may ask permission to install from that source.

Test:
1. Choose the original video using the system picker.
2. Tap Share and select TikTok YOU if it appears.
3. Compare with importing the same video from TikTok's own gallery picker.

This is an experimental prototype. A debug APK is unsigned for Play Store distribution but can be installed manually.
