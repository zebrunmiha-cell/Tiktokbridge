package com.example.tiktokbridge

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val pickVideoRequest = 4101
    private var selectedUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val title = TextView(this).apply {
            text = "TikTok Bridge 0.1\n\nПередаёт выбранный оригинальный файл напрямую через Android Sharesheet. Видео не перекодируется и не копируется приложением."
            textSize = 18f
            setPadding(24, 24, 24, 24)
        }
        val choose = Button(this).apply {
            text = "Выбрать оригинальное видео"
            setOnClickListener { chooseVideo() }
        }
        val share = Button(this).apply {
            text = "Передать в TikTok / другое приложение"
            isEnabled = false
            setOnClickListener { selectedUri?.let { shareOriginal(it) } }
            tag = "shareButton"
        }
        val note = TextView(this).apply {
            text = "Важно: Bridge не отключает серверное сжатие TikTok. Он лишь передаёт исходный URI без предварительного перекодирования. TikTok может не принимать общий способ передачи в конкретной версии приложения."
            textSize = 14f
            setPadding(24, 16, 24, 24)
        }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(16, 32, 16, 16)
            addView(title)
            addView(choose)
            addView(share)
            addView(note)
        }
        setContentView(layout)
    }

    private fun chooseVideo() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivityForResult(intent, pickVideoRequest)
    }

    @Deprecated("Legacy result callback is sufficient for this minimal prototype")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickVideoRequest && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            selectedUri = uri
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: SecurityException) {
                // A provider may return a temporary grant only. The immediate share still carries it.
            }
            findShareButton()?.isEnabled = true
            Toast.makeText(this, "Оригинал выбран. Нажми «Передать».", Toast.LENGTH_LONG).show()
        }
    }

    private fun findShareButton(): Button? {
        val root = findViewById<LinearLayout>(android.R.id.content).getChildAt(0) as? LinearLayout ?: return null
        for (i in 0 until root.childCount) {
            val child = root.getChildAt(i)
            if (child is Button && child.tag == "shareButton") return child
        }
        return null
    }

    private fun shareOriginal(uri: Uri) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = contentResolver.getType(uri) ?: "video/*"
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = android.content.ClipData.newUri(contentResolver, "Original video", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(Intent.createChooser(send, "Передать оригинальное видео"))
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось открыть меню передачи: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }
}
